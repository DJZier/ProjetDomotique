package fr.insa.ebf.LightMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LightMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
