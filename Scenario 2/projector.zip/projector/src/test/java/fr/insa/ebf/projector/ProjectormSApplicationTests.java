package fr.insa.ebf.projector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectormSApplicationTests {

	@Test
	void contextLoads() {
	}

}
