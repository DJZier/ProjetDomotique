package fr.insa.ebf.projector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectormSApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectormSApplication.class, args);
	}

}
